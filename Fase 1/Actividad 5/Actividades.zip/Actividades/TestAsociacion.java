public class TestAsociacion {
    /**
     * @param args
     */
    public static void main(String[] args) {
        Banco bcp = new Banco("BCP");
        Banco bbva = new Banco("BBVA", 30);
        Persona P1 = new Persona(211417, "Johan", "Mamani", 47474741);
        Persona P2 = new Persona(5511747, "Jose", "Caceres", 1757141);
        Persona P3 = new Persona(5511747, "Tsac", "Lopez", 27242577);
        bcp.agregarCliente(P1);
        bcp.agregarCliente(P2);
        bbva.agregarCliente(P3);
        System.out.println(bcp);
        System.out.println(bbva);
        // agregue clientes
        // elimine clientes
        // lista los clientes por tipo
        // busque clientes

    }
}
